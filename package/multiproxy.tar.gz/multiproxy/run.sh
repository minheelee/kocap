#!/bin/sh

#. /usr/local/bigdata/multiproxy/env.sh

cd /usr/local/bigdata/multiproxy/

./stop.sh

java -cp ./proxy-1.5.jar multiproxy -conf=./svc.conf >/dev/null 2>/dev/null &
