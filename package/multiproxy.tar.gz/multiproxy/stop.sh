#!/bin/sh

#. /usr/local/bigdata/multiproxy/env.sh

cd /usr/local/bigdata/multiproxy

ps -ef|grep multiproxy|grep -v grep|awk '{print $2}'|xargs kill -9 

